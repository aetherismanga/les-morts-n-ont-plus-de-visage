LES MORTS N'ONT PLUS DE VISAGE — ASSETS VALIDÉS

UI
01 — Fond général des pages secondaires
02 — Cadre / panneau sombre
03 — Séparateurs rouge / métal
04 — Éléments preuves / enquête
05 — Habillage Lecture vocale
06 — Habillage Chapitres
07 — Habillage Confort de lecture / Paramètres
08 — Habillage Mes musiques

ICÔNES PWA
- icon-192x192.png
- icon-512x512.png
- icon-maskable-512x512.png

RÈGLE D'INTÉGRATION
Ne pas intégrer automatiquement tous les assets dans GitHub.
Utiliser uniquement les éléments réellement nécessaires à chaque écran.
Ne pas remplacer les éléments déjà validés sans demande explicite.
